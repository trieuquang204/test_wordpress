wp.blocks.registerBlockStyle( 'core/separator', {
     name: 'snowflakes',
     label: 'Snowflakes'
});
wp.blocks.registerBlockStyle( 'core/quote', {
     name: 'style2',
     label: 'Style 2'
});
wp.blocks.registerBlockStyle( 'core/quote', {
     name: 'style3',
     label: 'Style 3'
});
wp.blocks.registerBlockStyle( 'core/list', {
     name: 'style1',
     label: 'Style star'
});